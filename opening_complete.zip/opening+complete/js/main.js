const toggleProjects = () => {
    const dashboard = document.getElementById("dashboard");
    toggleAttribute(dashboard, offscreen);
}